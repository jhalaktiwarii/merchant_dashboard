const express = require('express');
const router = express.Router();
const { getTransactions, addTransaction, processTransaction } = require('../controllers/transactionController');

router.get('/', getTransactions);
router.post('/', addTransaction);
router.post('/process', processTransaction);

module.exports = router;
