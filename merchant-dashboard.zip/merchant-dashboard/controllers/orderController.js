const Order = require('../models/Order');

exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find();
    res.json(orders);
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

exports.addOrder = async (req, res) => {
  const { orderId, amount } = req.body;

  try {
    const newOrder = new Order({
      orderId,
      amount,
    });

    const order = await newOrder.save();
    res.json(order);
  } catch (err) {
    res.status(500).send('Server Error');
  }
};
