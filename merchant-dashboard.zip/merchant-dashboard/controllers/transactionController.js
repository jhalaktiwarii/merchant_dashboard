const Transaction = require('../models/Transaction');
const Web3 = require('web3');
require('dotenv').config();

const web3 = new Web3(new Web3.providers.HttpProvider(process.env.INFURA_URL));

exports.getTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find();
    res.json(transactions);
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

exports.addTransaction = async (req, res) => {
  const { transactionId, amount } = req.body;

  try {
    const newTransaction = new Transaction({
      transactionId,
      amount,
    });

    const transaction = await newTransaction.save();
    res.json(transaction);
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

exports.processTransaction = async (req, res) => {
  const { to, value } = req.body;

  try {
    const privateKey = process.env.PRIVATE_KEY;
    const account = web3.eth.accounts.privateKeyToAccount(privateKey);
    const tx = {
      from: account.address,
      to,
      value: web3.utils.toWei(value, 'ether'),
      gas: 2000000,
    };

    const signedTx = await web3.eth.accounts.signTransaction(tx, privateKey);
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

    res.json({ transactionId: receipt.transactionHash });
  } catch (err) {
    res.status(500).send('Server Error');
  }
};
