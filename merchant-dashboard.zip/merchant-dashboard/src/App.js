import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Balance from './components/Balance';
import OrderDetails from './components/OrderDetails';
import TransactionHistory from './components/TransactionHistory';
import './App.css';

const App = () => {
  const [balance, setBalance] = useState(0);
  const [orders, setOrders] = useState([]);
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await axios.get('/api/orders');
        setOrders(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    const fetchTransactions = async () => {
      try {
        const res = await axios.get('/api/transactions');
        setTransactions(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    fetchOrders();
    fetchTransactions();
  }, []);

  return (
    <div className="app">
      <h1>Merchant Dashboard</h1>
      <Balance balance={balance} />
      <OrderDetails orders={orders} />
      <TransactionHistory transactions={transactions} />
    </div>
  );
};

export default App;
